

<?php $__env->startSection('content'); ?>
    <h2>Listado de ofertas</h2>
    
    <?php if(session('success')): ?>
        <h3 style="color: green"><?php echo e(session('success')); ?></h3>
    <?php endif; ?>
    <?php if(session('borrado')): ?>
        <h3 style="color: red"><?php echo e(session('borrado')); ?></h3>
    <?php endif; ?>

    <div class="container">
        <?php $__currentLoopData = $ofertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oferta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div style="border: 1px solid black;">
                <h3>Título: <?php echo e($oferta->titulo); ?></h3>
                <p>Nombre de la empresa: <?php echo e($oferta->empresas->nombre); ?></p>
                <p>Salario: <?php echo e($oferta->salario); ?>€</p>
                <p>Fecha de cierre: <?php echo e($oferta->fecha_cierre); ?></p>

                <a href="<?php echo e(route('ofertas.editar', $oferta->id)); ?> ">EDITAR</a>
                <br><br>
                <form action="<?php echo e(route('ofertas.destroy', $oferta->id)); ?>" method="POST">
                    <?php echo method_field('DELETE'); ?>
                    <?php echo csrf_field(); ?>

                    <button type="submit">BORRAR</button>
                </form>
                <!-- mensaje si la oferta es anterior a hoy -->
                <?php if($oferta->fecha_cierre < NOW()->format('Y-m-d')): ?>
                    <p style="color: red">OFERTA EXPIRADA</p>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sandra2EVAL\resources\views/ofertas/index.blade.php ENDPATH**/ ?>