<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Portal de empleo</title>
</head>
<body>
    <h1>PORTAL DE EMPLEO</h1>
    <nav>
        <ul>
            <li><a href=" <?php echo e(route('ofertas.index')); ?> ">Inicio</a></li>
            <li><a href=" <?php echo e(route('ofertas.crear')); ?> ">Crear Oferta</a></li>
        </ul>
    </nav>

    <?php echo $__env->yieldContent('content'); ?>

    <footer>
        <p style="text-align: center">Sandra Pico Álvarez - &#169 Portal de Empleo <?php echo e(date('Y')); ?></p>
    </footer>
</body>
</html><?php /**PATH C:\xampp\htdocs\Sandra2EVAL\resources\views/layouts/app.blade.php ENDPATH**/ ?>