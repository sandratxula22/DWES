

<?php $__env->startSection('title', 'Nuevos Chollos'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Nuevos Chollos</h1>
    <ul class="list-group">
        <?php $__currentLoopData = $chollos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chollo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item">
                <a href="<?php echo e(route('chollos.show', $chollo->id)); ?>"><?php echo e($chollo->titulo); ?></a>
                <span class="badge bg-success"><?php echo e($chollo->created_at->diffForHumans()); ?></span>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\daw\DWES\DWES\2_trimestre\Tema_8\proyecto2_Sandra\resources\views/chollos/nuevos.blade.php ENDPATH**/ ?>