<?php $__env->startSection('title', 'Inicio'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mt-4">Listado de Chollos</h1>

    <!-- LISTADO DE CHOLLOS -->
    <div class="row">
        <?php $__currentLoopData = $chollos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chollo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 mb-4">
            <div class="card shadow-sm">
                <div class="card-body">
                    <a href="<?php echo e(route('chollos.show', $chollo->id)); ?>">
                        <h5 class="card-title"><?php echo e($chollo->titulo); ?></h5>
                    </a>
                    <p class="card-text"><?php echo e($chollo->descripcion); ?></p>
                    <p><strong>Categoría:</strong> <?php echo e($chollo->categoria->name); ?></p>

                    <!-- EDITAR Y BORRAR -->
                    <a href="<?php echo e(route('chollos.edit', $chollo->id)); ?>" class="btn btn-primary">Editar</a>
                    <form action="<?php echo e(route('chollos.destroy', $chollo->id)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Borrar</button>
                    </form>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <!-- Mensaje editado -->
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <!-- Mensaje eliminado -->
    <?php if(session('eliminado')): ?>
        <div class="alert alert-danger"><?php echo e(session('eliminado')); ?></div>
    <?php endif; ?>

    <!-- PAGINACIÓN  -->
    <div class="d-flex justify-content-center">
        <?php echo e($chollos->links('pagination::bootstrap-5')); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\daw\DWES\DWES\2_trimestre\Tema_8\proyecto2_Sandra\resources\views/chollos/index.blade.php ENDPATH**/ ?>