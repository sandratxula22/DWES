<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mt-4"><?php echo e($chollo->titulo); ?></h1>

    <div class="card">
        <div class="card-body">
            <p><strong>Descripción:</strong> <?php echo e($chollo->descripcion); ?></p>
            <p><strong>Categoría:</strong> <?php echo e($chollo->categoria->name); ?></p>
            <p><strong>Precio:</strong> <?php echo e(number_format($chollo->precio, 2)); ?>€</p>
            <p><strong>Precio con Descuento:</strong> <?php echo e(number_format($chollo->precio_descuento, 2)); ?>€</p>
            <p><strong>Puntuación:</strong> <?php echo e($chollo->puntuacion); ?> estrellas</p>
            <p><strong>Enlace:</strong> <a href="<?php echo e($chollo->url); ?>" target="_blank"><?php echo e($chollo->url); ?></a></p>
        </div>
    </div>

    <!-- Botón para regresar al index -->
    <a href="<?php echo e(route('chollos.index')); ?>" class="btn btn-secondary mt-4">Regresar a la Página Principal</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\daw\DWES\DWES\2_trimestre\Tema_8\proyecto2_Sandra\resources\views/chollos/show.blade.php ENDPATH**/ ?>