

<?php $__env->startSection('title', 'Categorías'); ?>

<?php $__env->startSection('content'); ?>


<div class="container">
    <h1 class="mt-4">Listado de Categorías</h1>

    <!-- CREAR CATEGORÍA -->
    <div class="mb-3">
        <a href="<?php echo e(route('categorias.create')); ?>" class="btn btn-success">Crear Categoría</a>
    </div>

    <!-- LISTADO DE CATEGORÍAS -->
    <div class="row">
        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 mb-4">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($categoria->name); ?></h5>
                    <p><strong>Número de chollos asociados:</strong> <?php echo e(count($categoria->chollos)); ?></p>

                    <!-- BORRAR -->
                    <form action="<?php echo e(route('categorias.destroy', $categoria->id)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Borrar</button>
                    </form>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- Mensaje eliminado -->
    <?php if(session('categ-eliminada')): ?>
        <div class="alert alert-danger"><?php echo e(session('categ-eliminada')); ?></div>
    <?php endif; ?>

    <!-- PAGINACIÓN  -->
    <div class="d-flex justify-content-center">
        <?php echo e($categorias->links('pagination::bootstrap-5')); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\daw\DWES\DWES\2_trimestre\Tema_8\proyecto2_Sandra\resources\views/categorias/index.blade.php ENDPATH**/ ?>