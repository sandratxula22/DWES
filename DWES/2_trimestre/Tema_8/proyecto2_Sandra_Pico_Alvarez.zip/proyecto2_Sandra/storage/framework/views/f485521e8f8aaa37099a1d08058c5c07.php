<?php $__env->startSection('title', 'Editar chollo'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Editar Chollo</h1>

    <form action="<?php echo e(route('chollos.update', $chollo->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <label for="titulo" class="form-label">Título del Chollo</label>
            <input type="text" name="titulo" id="titulo" class="form-control" value="<?php echo e($chollo->titulo); ?>" >
        </div>

        <div class="mb-3">
            <label for="descripcion" class="form-label">Descripción</label>
            <textarea name="descripcion" id="descripcion" class="form-control" rows="4" ><?php echo e($chollo->descripcion); ?></textarea>
        </div>

        <div class="mb-3">
            <label for="categoria_id" class="form-label">Categoría</label>
            <select name="categoria_id" id="categoria_id" class="form-control" >
                <option value="">Seleccionar Categoría</option>
                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($categoria->id); ?>" <?php echo e($categoria->id == $chollo->categoria_id ? 'selected' : ''); ?>><?php echo e($categoria->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="puntuacion" class="form-label">Puntuación</label>
            <input type="number" name="puntuacion" id="puntuacion" class="form-control" value="<?php echo e($chollo->puntuacion); ?>" min="1" max="5" >
        </div>

        <div class="mb-3">
            <label for="precio" class="form-label">Precio</label>
            <input type="number" name="precio" id="precio" class="form-control" value="<?php echo e($chollo->precio); ?>" step="0.01" >
        </div>

        <div class="mb-3">
            <label for="precio_descuento" class="form-label">Precio con Descuento</label>
            <input type="number" name="precio_descuento" id="precio_descuento" class="form-control" value="<?php echo e($chollo->precio_descuento); ?>" step="0.01" >
        </div>

        <div class="mb-3">
            <label for="url" class="form-label">Enlace al Chollo</label>
            <input type="url" name="url" id="url" class="form-control" value="<?php echo e($chollo->url); ?>" >
        </div>

        <button type="submit" class="btn btn-primary">Actualizar</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\daw\DWES\DWES\2_trimestre\Tema_8\proyecto2_Sandra\resources\views/chollos/edit.blade.php ENDPATH**/ ?>