

<?php $__env->startSection('title', 'Crear categoría'); ?>

<?php $__env->startSection('content'); ?>
<h1>Añadir Categoría</h1>

<form action="<?php echo e(route('categorias.insert')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label for="name" class="form-label">Nombre de la Categoría:</label>
        <input type="text" class="form-control" id="name" name="name">
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger">Debes rellenar el nombre</div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <button type="submit" class="btn btn-primary">Crear</button>
</form>
<?php if(session('categ-added')): ?>
    <div class="alert alert-success"><?php echo e(session('categ-added')); ?></div>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\daw\DWES\DWES\2_trimestre\Tema_8\proyecto2_Sandra\resources\views/categorias/create.blade.php ENDPATH**/ ?>